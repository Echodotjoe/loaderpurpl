Place all your .swf and .html game files inside this directory!
Example: items/mygame.swf
items/mygame.html
